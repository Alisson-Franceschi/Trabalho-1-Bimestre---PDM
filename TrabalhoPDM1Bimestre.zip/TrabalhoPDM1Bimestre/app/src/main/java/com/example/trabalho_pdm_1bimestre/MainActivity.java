package com.example.trabalho_pdm_1bimestre;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etNome;
    private EditText etIdade;
    private EditText etEmail;
    private EditText etDisciplina;
    private EditText etNota1B;
    private EditText etNota2B;
    private TextView tvResumoInfo;
    private Button btMostrarMedia;
    private Button btLimpar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNome = findViewById(R.id.etNome);
        etIdade = findViewById(R.id.etIdade);
        etEmail = findViewById(R.id.etEmail);
        etDisciplina = findViewById(R.id.etDisciplina);
        etNota1B = findViewById(R.id.etNota1B);
        etNota2B = findViewById(R.id.etNota2B);
        tvResumoInfo = findViewById(R.id.tvResumoInfo);
        btMostrarMedia = findViewById(R.id.btMostrarMedia);
        btLimpar = findViewById(R.id.btLimpar);

        btMostrarMedia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mensagemErro = verificarCampos();

                if(mensagemErro.equals("")) {
                    String media = String.valueOf(CalcularMedia());
                    String nome = etNome.getText().toString();
                    String idade = etIdade.getText().toString();
                    String email = etEmail.getText().toString();
                    String disciplina = etDisciplina.getText().toString();
                    String nota1 = etNota1B.getText().toString();
                    String nota2 = etNota2B.getText().toString();

                    tvResumoInfo.setText("Nome: " + nome + "\n" +
                            "Idade: " + idade + "\n" +
                            "E-Mail: " + email + "\n" +
                            "Disciplina: " + disciplina + "\n" +
                            "Notas 1o e 2o Bimestres: " + nota1 + " e " + nota2 + "\n" +
                            "Média: " + media);
                    tvResumoInfo.setVisibility(View.VISIBLE);
                }
                else{
                    tvResumoInfo.setText(mensagemErro);
                    tvResumoInfo.setVisibility(View.VISIBLE);
                }
            }
        });

        btLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etNome.setText("");
                etEmail.setText("");
                etIdade.setText("");
                etDisciplina.setText("");
                etNota1B.setText("");
                etNota2B.setText("");
                tvResumoInfo.setText("");
                tvResumoInfo.setVisibility(View.GONE);
            }
        });

    }

    private double CalcularMedia(){
        double nota1 = Double.parseDouble(etNota1B.getText().toString());
        double nota2 = Double.parseDouble(etNota2B.getText().toString());
        double media = (nota1 + nota2) / 2;
        return media;
    }

    private String verificarCampos(){
        String mensagem = "";
        String email = etEmail.getText().toString();

        if(etNome.getText().toString().isEmpty()){
            mensagem += ("O campo de Nome está vazio!" + "\n");
        }

        if(etEmail.getText().toString().isEmpty()){
            mensagem += ("O campo de Email está vazio!" + "\n");
        }
        else {
            if (email.contains("@")) {
                mensagem += "";
            } else {
                mensagem += ("Email inválido" + "\n");
            }
        }

        if(etIdade.getText().toString().isEmpty()){
            mensagem += ("O campo de Idade está vazio!" + "\n");
        }
        else {
            try {
                int idade = Integer.parseInt(etIdade.getText().toString());
                if (idade < 0) {
                    mensagem += ("Idade precisa ser um número positivo" + "\n");
                }
            } catch (NumberFormatException e) {
                mensagem += ("Idade precisa ser um número" + "\n");
            }
        }

        if(etDisciplina.getText().toString().isEmpty()){
            mensagem += ("O campo de Disciplina está vazio!" + "\n");
        }

        if(etNota1B.getText().toString().isEmpty()){
            mensagem += ("O campo da nota do bimestre 1 está vazio!" + "\n");
        }
        else {
            try {
                double nota = Double.parseDouble(etNota1B.getText().toString());
                if ((nota < 0) || (nota > 10)) {
                    mensagem += ("A nota 1 precisa ser um valor entre 0 e 10" + "\n");
                }
            } catch (NumberFormatException e) {
                mensagem += ("A nota 1 precisa ser um número (inteiro ou decimal)" + "\n");
            }
        }

        if(etNota2B.getText().toString().isEmpty()){
            mensagem += ("O campo da nota do bimestre 2 está vazio!" + "\n");
        }
        else {
            try {
                double nota = Double.parseDouble(etNota2B.getText().toString());
                if ((nota < 0) || (nota > 10)) {
                    mensagem += ("A nota 2 precisa ser um valor entre 0 e 10" + "\n");
                }
            } catch (NumberFormatException e) {
                mensagem += ("A nota 2 precisa ser um número (inteiro ou decimal)" + "\n");
            }
        }

        return mensagem;
    }
}